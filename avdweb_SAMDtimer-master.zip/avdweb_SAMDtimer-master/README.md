# Avdweb_SAMDtimer
SAMD21 Timer library for the SAM15x15 and Arduino Zero
http://www.avdweb.nl/arduino/libraries/samd21-timer.html
